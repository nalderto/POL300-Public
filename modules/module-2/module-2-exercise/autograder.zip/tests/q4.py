test = {'name': 'q4',
        'points': 1,
        'suites': [{'cases': [{'code': '>>> car = {"color": "red", "year": 2001, "model": "S90", "insurance": "Allstate"}\n >>> car = updateListing(car)\n >>> assert car["color"] == "white"\n >>> assert car["year"] == 1997\n >>> assert car["make"] == "Volvo"\n >>> assert car["model"] == "S90"\n >>> assert "insurance" not in car.values() \n',
                               'hidden': False, 'locked': False}],
                    'scored': True,
                    'setup': '',
                    'teardown': '',
                    'type': 'doctest'}]}
